﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=hotel_billing_system; Integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "Employee")
        {
            SqlDataAdapter ad = new SqlDataAdapter("select name,email_id ,password from employee_registration where email_id = '" + TextBox1.Text + "' and password = '" + TextBox2.Text + "'", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);

            Session["user_name"] = dt.Rows[0][0].ToString();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("bill.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid Login')</script>");
            }
        }
        else
        {
            SqlDataAdapter ad = new SqlDataAdapter("select email_id ,password from admin where email_id = '" + TextBox1.Text + "' and password = '" + TextBox2.Text + "'", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("admin.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid Login')</script>");
            }
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.IO;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=hotel_billing_system; Integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {

        DateTime.Now.Date.ToShortDateString();
        Label2.Text ="Time: "+DateTime.Now.ToShortTimeString();

        if (!IsPostBack)
        {
            Label1.Text = Session["user_name"].ToString();

            Panel1.Visible = false;
            DropDownList1.Width = 150;
            DropDownList1.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
            Label6.Visible = false;
            Label7.Visible = false;
            TextBox1.Visible = false;
            Button1.Visible = false;
            Button3.Visible = false;
            RadioButtonList1.ClearSelection();
            TextBox1.Text = "";

            foreach (ListItem li in DropDownList1.Items)
            {

                //li.Attributes.Add("style", "background-color:black;color:yellow;");
                li.Attributes.Add("style", "color:black;");
            }
            
        }
        
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList1.Visible = true;
        TextBox1.Visible = true;
        RadioButtonList1.Visible = true;
        Label3.Visible = true;
        Label4.Visible = true;
        TextBox1.Visible = true;
        Button1.Visible = true;
        Button3.Visible = true;
        
        if (RadioButtonList1.SelectedValue == "Tiffen")
        {
            SqlDataAdapter ad1 = new SqlDataAdapter("select item from menu where cid='1'",con);
            DataTable dt1 = new DataTable();
            ad1.Fill(dt1);
            
            DropDownList1.DataSource = dt1;
            DropDownList1.DataTextField = "item";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("---Select---", ""));
            //DropDownList1.Items[1].Attributes.Add("style", "color:Red");
            //foreach (ListItem li in DropDownList1.Items)
            //{

            //    li.Attributes.Add("style", "background-color:black;color:yellow;");
            //}

            foreach (ListItem li in DropDownList1.Items)
            {

                //li.Attributes.Add("style", "background-color:black;color:yellow;");
                li.Attributes.Add("style", "color:black;");
            }

        }
        if(RadioButtonList1.SelectedValue == "Lunch")
        {
            SqlDataAdapter ad2 = new SqlDataAdapter("select item from menu where cid='2'", con);
            DataTable dt2 = new DataTable();
            ad2.Fill(dt2);

            DropDownList1.DataSource = dt2;
            DropDownList1.DataTextField = "item";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("---Select---", ""));
            //foreach (ListItem li in DropDownList1.Items)
            //{

            //    li.Attributes.Add("style", "background-color:black;color:yellow;");
            //}

            foreach (ListItem li in DropDownList1.Items)
            {

                //li.Attributes.Add("style", "background-color:black;color:yellow;");
                li.Attributes.Add("style", "color:black;");
            }
        }
        if (RadioButtonList1.SelectedValue == "Snaks")
        {
            SqlDataAdapter ad3 = new SqlDataAdapter("select item from menu where  cid='3'", con);
            DataTable dt3 = new DataTable();
            ad3.Fill(dt3);

            DropDownList1.DataSource = dt3;
            DropDownList1.DataTextField = "item";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("---Select---", ""));
            //foreach (ListItem li in DropDownList1.Items)
            //{

            //    li.Attributes.Add("style", "background-color:black;color:yellow;");
            //}

            foreach (ListItem li in DropDownList1.Items)
            {

                //li.Attributes.Add("style", "background-color:black;color:yellow;");
                li.Attributes.Add("style", "color:black;");
            }
        }
        if (RadioButtonList1.SelectedValue == "Beverages")
        {
            SqlDataAdapter ad3 = new SqlDataAdapter("select item from menu where cid='4'", con);
            DataTable dt3 = new DataTable();
            ad3.Fill(dt3);

            DropDownList1.DataSource = dt3;
            DropDownList1.DataTextField = "item";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("---Select---", ""));
            
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        foreach (ListItem li in DropDownList1.Items)
        {

            //li.Attributes.Add("style", "background-color:black;color:yellow;");
            li.Attributes.Add("style", "color:black;");
        }

        int bill_no;
        SqlDataAdapter ad1 = new SqlDataAdapter("select max(bill_no) from bill_backup", con);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        if (dt1.Rows.Count > 0)
        {

            if (dt1.Rows[0][0].ToString() == "")
            {
                bill_no = 1001;
            }
            else
            {
                bill_no = Convert.ToInt32(dt1.Rows[0][0].ToString()) + 1;
            }
            Label8.Text = "Bill No: " + bill_no.ToString();

        }

        if (DropDownList1.SelectedValue == "Select Category")
        {
            Response.Write("<script>alert('Select Category')</script>");
        }
        else
        {

            Panel1.Visible = true;
            int rate, total;
            SqlDataAdapter ad = new SqlDataAdapter("select rate from menu where item = '" + DropDownList1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);


            rate = Convert.ToInt32(dt.Rows[0][0].ToString());
            total = Convert.ToInt32(dt.Rows[0][0].ToString()) * Convert.ToInt32(TextBox1.Text);

            SqlCommand cmd = new SqlCommand("insert into bill_print (item,quantity,rate,total) values ('" + DropDownList1.SelectedValue + "','" + TextBox1.Text + "','" + rate + "','" + total + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            SqlDataAdapter ad11 = new SqlDataAdapter("select * from bill_print", con);
            DataTable dt11 = new DataTable();
            ad11.Fill(dt11);
            GridView1.DataSource = dt11;
            GridView1.DataBind();
            SqlDataAdapter ad2 = new SqlDataAdapter("select sum(total) from bill_print", con);
            DataTable dt2 = new DataTable();
            ad2.Fill(dt2);

            Label6.Visible = true;
            Label7.Visible = true;

            Label6.Text = "Rs." + dt2.Rows[0][0].ToString();
        }

        
    }
   
    protected void Button2_Click(object sender, EventArgs e)
    {
        Button2.Attributes.Add("onclick", "Button2_Click()");

        

        int bill_no;
        SqlDataAdapter ad1 = new SqlDataAdapter("select max(bill_no) from bill_backup",con);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        if(dt1.Rows.Count > 0)
        {

            if (dt1.Rows[0][0].ToString() == "")
            {
                bill_no = 1001;
            }
            else
            {
                bill_no = Convert.ToInt32(dt1.Rows[0][0].ToString()) + 1;
            }
             SqlDataAdapter ad2 = new SqlDataAdapter("select sum(total) from bill_print", con);
            DataTable dt2 = new DataTable();
            ad2.Fill(dt2);
            try
            {
                int t = Convert.ToInt32(dt2.Rows[0][0].ToString());
                SqlCommand cmd1 = new SqlCommand("insert into bill_backup values ('" + Label1.Text + "','" + bill_no + "','" + t + "')", con);
                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
            }
            catch(FormatException f)
            {
                Response.Redirect("bill.aspx");
            }
            
            


            SqlCommand cmd = new SqlCommand("truncate table bill_print", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

           

        }
       
        
       
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DropDownList1.Items.Clear();
        DropDownList1.Items.Insert(0, new ListItem("Select Category", ""));
        
        SqlCommand cmd = new SqlCommand("truncate table bill_print", con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        RadioButtonList1.ClearSelection();
        TextBox1.Text = "";
        DropDownList1.ClearSelection();
        Panel1.Visible = false;
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
       
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
    }
}

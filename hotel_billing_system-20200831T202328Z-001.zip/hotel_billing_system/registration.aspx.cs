﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=hotel_billing_system; Integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int emp_id;
        SqlDataAdapter ad1 = new SqlDataAdapter("select max(emp_id) from employee_registration",con);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);
        if (dt1.Rows.Count > 0)
        {
            if (dt1.Rows[0][0].ToString() == "")
            {
                emp_id = 1001;
            }
            else
            {
                emp_id = Convert.ToInt32( dt1.Rows[0][0].ToString()) + 1;
            }
            string dob = DropDownList1.SelectedValue + "/" + DropDownList2.SelectedValue + "/" + DropDownList3.SelectedValue;
            if (TextBox8.Text == TextBox9.Text)
            {
                SqlCommand cmd = new SqlCommand("insert into employee_registration values('" + emp_id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + dob + "','" + RadioButtonList1.SelectedValue + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Data Registered')</script>");
                con.Close();
            }
            else
            {
                Response.Write("<script>alert('Password Doesn't Match')</script>");
            }
        }
     }


    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
}
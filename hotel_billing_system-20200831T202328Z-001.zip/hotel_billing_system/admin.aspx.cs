﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin : System.Web.UI.Page
{
     
    
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=hotel_billing_system; Integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }

    protected void RadioButtonList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
  
    protected void Button1_Click(object sender, EventArgs e)
    {
        int id;
        int cid=0;
        SqlDataAdapter ad = new SqlDataAdapter("select max(id) from menu",con);
        DataTable dt = new DataTable();
        ad.Fill(dt);

        if(dt.Rows.Count > 0)
        {
            if(dt.Rows[0][0].ToString() == "")
            {
                id=101; 
            }
            else
            {
                id = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;
        
            }

            if (RadioButtonList2.SelectedValue == "Tiffen")
            {
                cid = 1;
                SqlCommand cmd = new SqlCommand("insert into menu values('" + id + "','" + cid + "','" + TextBox1.Text + "','" + TextBox2.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Item Added')</script>");
                con.Close();
            }
            else if (RadioButtonList2.SelectedValue == "Lunch")
            {
                cid = 2;
                SqlCommand cmd = new SqlCommand("insert into menu values('" + id + "','" + cid + "','" + TextBox1.Text + "','" + TextBox2.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Item Added')</script>");
                con.Close();
            }
            else if (RadioButtonList2.SelectedValue == "Snaks")
            {
                cid = 3;
                SqlCommand cmd = new SqlCommand("insert into menu values('" + id + "','" + cid + "','" + TextBox1.Text + "','" + TextBox2.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Item Added')</script>");
                con.Close();
            }
            else if (RadioButtonList2.SelectedValue == "Beverages")
            {
                cid = 4;
                SqlCommand cmd = new SqlCommand("insert into menu values('" + id + "','" + cid + "','" + TextBox1.Text + "','" + TextBox2.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Item Added')</script>");
                con.Close();
            }

               
            
        }

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
}